# App Update
The App is made on Android Studio and also using Google Firebase \
Intially the app has many ui/ux and bug issues .\
But in the updated version .......,\
The things which is fixed and Shoutouts(who helped a lot) !



1)Major UI/UX change\
  *As changes have been idealised by @chinmay bhaiya \
    #Backgrond colour changes (Ambient colour )\
    #Button rounded\
    #Button colour(Ambient colour)\
    #Animation (Thanks to lottiefiles.com{its an open community with talented animators})\
    #Dialog Box added wherever needed!\
    #Using Recycler View instead of List view (saves memory , light ,and fast)\
2)BUG fixes\
     *Changes as per uses and feedback !\
     #User side ->Register button( clicking even  without data it enters another activity)\
3)Email new user interface added .\
4)Thanx for the youtube tutroial out there ! :)
